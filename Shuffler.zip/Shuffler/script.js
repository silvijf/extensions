var selectedElement;

let everyElement = document.querySelectorAll("*")
everyElement.forEach((element) => {
    if (element.textContent.length > 1 && element.children.length == 0) {
        if (element.tagName != "input") {
            element.addEventListener("click", () => {
                selectedElement = element
            })
        }
    }
})

document.addEventListener("keydown", (event) => {
    if (event.key == "=") shuffle()
})

function shuffle() {
    let string = selectedElement.textContent.split("")
    for (let i = string.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [string[i], string[j]] = [string[j], string[i]];
    }
    selectedElement.textContent = string.join("")

}